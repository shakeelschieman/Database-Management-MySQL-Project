/***************************************************************
* Author:   Shakeel Schieman
* Date:     16 January 2024
* Filename: Index tables.sql
* Description: This sql file will be showing the index created for all the tables in the database
****************************************************************/

USE MultiplayerOnlineGame;

# Creates index on account name column in account table
CREATE INDEX index_account_name ON account (account_Name);

# Creates index on account ID column in error_table table
CREATE INDEX index_error_table ON error_table(account_ID);

# Creates index on character Name column in characters table
CREATE INDEX index_character_name ON characters (character_Name);

# Creates index on character ID column in item table
CREATE INDEX index_item_character_id ON item (character_ID);

# Creates index on account ID column in accountCharacter table
CREATE INDEX index_account_character_account_id ON accountCharacter (account_ID);

# Creates index on item ID column in itemInventory table
CREATE INDEX idx_item_inventory_item_id ON itemInventory (item_ID);