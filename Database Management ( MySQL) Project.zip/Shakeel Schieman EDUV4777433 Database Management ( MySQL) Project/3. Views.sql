/***************************************************************
* Author:   Shakeel Schieman
* Date:     15 January 2024
* Filename: Views.sql
* Description: This sql file will be showing the views created for the tables.
****************************************************************/

# We will first drop the view "vwBlockedAccounts" if it exists and then recreate it.
DROP VIEW IF EXISTS vwBlockedAccounts;
CREATE VIEW vwBlockedAccounts AS
    SELECT 
        *
    FROM
        account
    WHERE
        account_status = 'Blocked';
		# The WHERE statement will make sure that the colum "account_status" MUST show the accounts that are blocked.
        
SELECT * FROM vwBlockedAccounts; # Displaying the view vwBlockedAccounts.
    
    
# We will first drop the view "vwTopSkill" if it exists and then recreate it.
DROP VIEW IF EXISTS vwTopSkill;
CREATE VIEW vwTopSkill AS
    SELECT 
        c.character_id,
        c.character_name,
        c.character_team,
        c.character_skill_level,
        a.account_name
    FROM
        characters c
            JOIN
        accountCharacter ac ON c.character_id = ac.character_id
            JOIN
        account a ON ac.account_id = a.account_id
    ORDER BY c.character_skill_level DESC
    LIMIT 20;
    #Makes sure to limit the amount of characters by 20 but since we only have 6 it will only display 6 characters

SELECT * FROM vwTopSkill; # Displaying the view vwTopSkill

# We will first drop the view "vwTopStackedItems" if it exists and then recreate it.
DROP VIEW IF EXISTS vwTopStackedItems;
CREATE VIEW vwTopStackedItems AS
    SELECT 
        i.item_id,
        i.item_name,
        i.item_type,
        COUNT(*) AS stack_count,
        GROUP_CONCAT(DISTINCT i.character_id) AS character_ids
    FROM
        item i
            JOIN
        inventory inv ON i.item_name IN (inv.inventory_slot_1 , inv.inventory_slot_2,
            inv.inventory_slot_3,
            inv.inventory_slot_4,
            inv.inventory_slot_5,
            inv.inventory_slot_6,
            inv.inventory_slot_7,
            inv.inventory_slot_8)
    GROUP BY i.item_id , i.item_name , i.item_type
    ORDER BY stack_count DESC
    LIMIT 20;
	
SELECT * FROM vwTopStackedItems;  #Displaying the view vwTopStackeditems

DROP VIEW IF EXISTS vwPopItems;


CREATE VIEW vwPopItems AS
    SELECT 
        i.item_id,
        i.item_name,
        COUNT(DISTINCT i.character_id) AS num_characters
    FROM
        itemInventory ii
            JOIN
        item i ON i.item_id = i.item_id
    GROUP BY i.item_id , i.item_name
    ORDER BY num_characters DESC
    LIMIT 5;


SELECT * FROM vwPopItems; # Displaying the view vwPopItems