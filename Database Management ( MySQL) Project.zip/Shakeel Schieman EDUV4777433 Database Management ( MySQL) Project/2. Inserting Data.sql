/***************************************************************
* Author:   Shakeel Schieman
* Date:     15 January 2024
* Filename: Insert.sql
* Description: This sql file will be used to insert records into the tables of the MultiplayerOnlineGame Database.
****************************************************************/

# We will use the database once again to ensure we insert the records into the correct tables.
USE MultiplayerOnlineGame;


# Inserting data into the account table
INSERT INTO account (account_name, paying_fee, account_status) 
VALUES 
  ('Dreamybee2701', 50.00, 'Active'),
  ('JaggerBomber', 25.00, 'Blocked'),
  ('TetrisBreaker', 75.50, 'Blocked'),
  ('Conan-Kun', 30.00, 'Active'),
  ('Bieber_Fever', 45.75, 'Blocked'),
  ('AdoredShadow', 15.00, 'Blocked');
  
SELECT * FROM account; # Displaying the data we inserted from the account table.

# Inserting data into the error_table
INSERT INTO error_table (error_type, error_desc, account_id) 
VALUES 
  ('Login Error', 'Invalid username', 1),
  ('Payment Error', 'Card declined', 3),
  ('Login Error', 'Incorrect password', 2),
  ('Payment Error', 'Card declined', 4),
  ('Login Error', 'Account blocked', 5),
  ('Login Error', 'Account blocked', 1);
  
SELECT * FROM error_table; # Displaying the data we inserted from the error_table table.

# Inserting data into the characters table
INSERT INTO characters (character_name, character_team, character_skill_level) 
VALUES 
  ('Mash', 'Team A', 10),
  ('Conan', 'Team B', 4),
  ('Denji', 'Team C', 12),
  ('Itadori', 'Team D', 18),
  ('Naruto', 'Team E', 20),
  ('Miles', 'Team F', 7);
  
SELECT * FROM characters; # Displaying the data we inserted from the characters table.

# Inserting data into the item table
INSERT INTO item (item_name, item_type, character_id) 
VALUES 
  ('Sword', 'Weapon', 1),
  ('Shield', 'Armor', 2),
  ('Potion', 'Consumable', 3),
  ('Gun', 'Weapon', 4),
  ('Hammer', 'Weapon', 5),
  ('Med-Kit', 'Consumable',6);
SELECT * FROM item; # Displaying the data we inserted from the items table.

# Inserting data into the inventory table
INSERT INTO inventory(
	inventory_slot_1, inventory_slot_2, inventory_slot_3, inventory_slot_4,
    inventory_slot_5, inventory_slot_6, inventory_slot_7, inventory_slot_8)
VALUES
    ('Sword', 'Shield', 'Potion', 'Potion', 'Hammer', 'Gun', 'Shield', 'Shield'),
    ('Sword', 'Potion', 'Shield', 'Shield', 'Shield', 'Gun', 'Sword', 'Hammer'),
    ('Potion', 'Potion', 'Potion', 'Gun', 'Gun', 'Med-kit', 'Shield', 'Hammer'),
    ('Potion', 'Potion', 'Potion', 'Gun', 'Gun', 'Hammer', 'Shield', 'Hammer'),
	('Sword', 'Potion', 'Shield', 'Shield', 'Shield', 'Gun', 'Sword', 'Med-kit'),
    ('Hammer', 'Potion', 'Med-kit', 'Gun', 'Gun', 'Med-kit', 'Shield', 'Hammer');
    
SELECT * FROM inventory; # Displaying the data we inserted from the inventory table.

# Inserting data into the accountCharacter table
INSERT INTO accountCharacter (account_id, character_id) 
VALUES 
  (1, 1),
  (2, 2),
  (3, 3),
  (4, 4),
  (5, 5),
  (6, 6);
SELECT * FROM accountCharacter; # Displaying the data we inserted from the accountCharacter Table.

# Inserting data into the itemInventory table
INSERT INTO itemInventory (item_id, inventory_id, item_quantity) 
VALUES 
  (1, 1, 3),
  (2, 2, 1),
  (3, 3, 5),
  (4, 4, 2),
  (5, 5, 4),
  (6, 6, 2);
SELECT * FROM iteminventory; # Displaying the data we inserted from the itemInventory table.