/***************************************************************
* Author:   Shakeel Schieman
* Date:     16 January 2024
* Filename: spRegister.sql
* Description: This sql file will be showing the first procedure created.
****************************************************************/

USE multiplayerOnlineGame;

DELIMITER //

DROP PROCEDURE IF EXISTS spRegister;
CREATE PROCEDURE spRegister(
    IN p_account_Name VARCHAR(30),
    IN p_paying_Fee DECIMAL(10, 2),
    IN p_account_Status VARCHAR(10)
    # Included all account details as arguments
)
BEGIN
    DECLARE accountExists INT;

    # Checking if the account already exists
    SELECT COUNT(*) INTO accountExists
    FROM account
    WHERE account_Name = p_account_Name;

    # If the account name doesn't exist it will insert the arguments into the account table
    IF accountExists = 0 THEN
        INSERT INTO account (account_Name, paying_Fee, account_Status)
        VALUES (p_account_Name, p_paying_Fee, p_account_Status);

        SELECT 'Account registered' AS Result;
    ELSE
        SELECT 'Account name is existing. Choose a different account name.' AS Result;
    END IF;
END //

DELIMITER ;

# Calling the procedure to see if it works
CALL spRegister('Boxing10', 50.00, 'Blocked');

