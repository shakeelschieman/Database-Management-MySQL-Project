/***************************************************************
* Author:   Shakeel Schieman
* Date:     16 January 2024
* Filename: spSendLetter.sql
* Description: This sql file will show how the fifth procedure works
****************************************************************/

USE multiplayeronlinegame;

DELIMITER //
DROP PROCEDURE IF EXISTS spSendLetter;
CREATE PROCEDURE spSendLetter(
    IN p_sendNews BOOLEAN
)
BEGIN
    DECLARE accountID INT;
    DECLARE accountName VARCHAR(30);
    DECLARE timeLeft DECIMAL(10, 2);
    DECLARE letterText VARCHAR(500);
	# Delcaring 4 variables 
    
    # Fetching account details
    DECLARE accountCursor CURSOR FOR
        SELECT account_ID, account_Name, paying_Fee
        FROM account;

    # Declare continuing
    DECLARE CONTINUE HANDLER FOR NOT FOUND
        SET accountID = NULL;

    # Opening the cursor
    OPEN accountCursor;

    # Now we will loop through each account
    read_accounts: LOOP
        -- Fetch account details
        FETCH accountCursor INTO accountID, accountName, timeLeft;

        
        IF accountID IS NULL THEN
            LEAVE read_accounts;
        END IF;

        # creating the  letter text
        SET letterText = CONCAT('Hello ', accountName,
            ',\nYour account has ', timeLeft, ' days remaining.');

        
        IF p_sendNews THEN
            SET letterText = CONCAT(letterText, '\nLatest news: [Your latest news here]');
        END IF;

        # Printing the letter
        SELECT letterText AS Letter;
    END LOOP;

    -- Close the cursor
    CLOSE accountCursor;
END //

DELIMITER ;

CALL spSendLetter(TRUE);
