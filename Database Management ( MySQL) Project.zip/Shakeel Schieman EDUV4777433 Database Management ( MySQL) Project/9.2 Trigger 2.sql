/***************************************************************
* Author:   Shakeel Schieman
* Date:     16 January 2024
* Filename: Triggers 1.2.sql
* Description: This sql file will show how the first trigger works
****************************************************************/
USE multiplayeronlinegame;

DELIMITER //

CREATE TRIGGER after_insert_itemInventory # Creating trigger
AFTER INSERT
ON itemInventory FOR EACH ROW
BEGIN
    UPDATE inventory
    SET total_item_quantity = (
        SELECT SUM(item_Quantity)
        FROM itemInventory
        WHERE inventory_ID = NEW.inventory_ID
    )
    WHERE inventory_ID = NEW.inventory_ID;
END //


DELIMITER ;
# Inserting a new item into the inventory
INSERT INTO itemInventory (item_ID, inventory_ID, item_Quantity)
VALUES (2, 1, 3);

SELECT * FROM iteminventory; # Displaying the newly added data