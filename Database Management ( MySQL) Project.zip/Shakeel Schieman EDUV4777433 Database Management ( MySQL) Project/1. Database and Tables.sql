/***************************************************************
* Author:   Shakeel Schieman
* Date:     15 January 2024
* Filename: Database and Tables.sql
* Description: This sql file contains neccessary Database along with its tables.
****************************************************************/

# Dropping and Creating Database again.
DROP DATABASE IF EXISTS MultiplayerOnlineGame;
CREATE DATABASE MultiplayerOnlineGame;

# We will be using the MultiplayerOnlineGame Database to create the tables within.
USE MultiplayerOnlineGame;

# Creating the account table.
CREATE TABLE account(
	account_ID INT NOT NULL AUTO_INCREMENT,
    account_Name VARCHAR(30) NOT NULL,
	paying_Fee DECIMAL(10, 2) NOT NULL,
    account_Status VARCHAR(10) NOT NULL,
    PRIMARY KEY (account_ID)

);

#Creating the error table which will have the foreign key to the account table because errors will mainly happen to the account.
CREATE TABLE error_table(
	error_ID INT NOT NULL AUTO_INCREMENT,
    error_Type VARCHAR(20) NOT NULL,
    error_Desc VARCHAR(100) NULL,
    account_ID INT NOT NULL,
    FOREIGN KEY (account_ID) REFERENCES account (account_ID),
    PRIMARY KEY (error_ID)

);

# Creating the characters table.
CREATE TABLE characters(
	character_ID INT NOT NULL AUTO_INCREMENT,
    character_Name VARCHAR(30) NOT NULL,
    character_Team VARCHAR(30) NOT NULL,
    character_Skill_Level INT NOT NULL,
    PRIMARY KEY (character_ID)

);


# Creating the item table.
CREATE TABLE item(
	item_ID INT NOT NULL AUTO_INCREMENT,
    item_Name VARCHAR(20) NOT NULL,
    item_type VARCHAR(20) NOT NULL,
    character_ID INT NOT NULL,
    FOREIGN KEY (character_ID) REFERENCES characters (character_ID),
    PRIMARY KEY (item_ID)

);


# Creating the inventory table.
CREATE TABLE inventory(
	inventory_ID INT NOT NULL AUTO_INCREMENT,
    inventory_slot_1 VARCHAR(10) NOT NULL,
    inventory_slot_2 VARCHAR(10) NOT NULL,
    inventory_slot_3 VARCHAR(10) NOT NULL,
    inventory_slot_4 VARCHAR(10) NOT NULL,
    inventory_slot_5 VARCHAR(10) NOT NULL,
    inventory_slot_6 VARCHAR(10) NOT NULL,
    inventory_slot_7 VARCHAR(10) NOT NULL,
    inventory_slot_8 VARCHAR(10) NOT NULL,
    PRIMARY KEY (inventory_ID)
    
);

# Creating Account/Character table.
CREATE TABLE accountCharacter(
	account_ID INT NOT NULL,
    character_ID INT NOT NULL,
    
    FOREIGN KEY (account_ID) REFERENCES account (account_ID),
    FOREIGN KEY (character_ID) REFERENCES characters (character_ID),
    PRIMARY KEY (account_ID, character_ID)
	
);

# Creating Item/Inventory table.
CREATE TABLE itemInventory(
	item_ID INT NOT NULL,
    inventory_ID INT NOT NULL,
    item_Quantity INT NOT NULL,
    
    FOREIGN KEY (item_ID) REFERENCES item (item_ID),
    FOREIGN KEY (inventory_ID) REFERENCES inventory (inventory_ID),
    PRIMARY KEY (item_ID, inventory_ID)

);