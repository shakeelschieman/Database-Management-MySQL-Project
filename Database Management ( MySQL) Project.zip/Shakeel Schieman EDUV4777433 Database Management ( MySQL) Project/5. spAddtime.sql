/***************************************************************
* Author:   Shakeel Schieman
* Date:     16 January 2024
* Filename: spAddtime.sql
* Description: This sql file will be showing the second procedure created.
****************************************************************/


USE MultiplayerOnlineGame;

DELIMITER //

DROP PROCEDURE IF EXISTS spAddtime;
CREATE PROCEDURE spAddTime(
    IN p_account_Name VARCHAR(30),
    IN p_length_of_time INT
)
BEGIN
    DECLARE accountID INT;

    # Checking to see if the account name exists.
    SELECT account_ID INTO accountID # Storing the official account_id from the account table into a created variable.
    FROM account
    WHERE account_Name = p_account_Name;
    # Storing the account name from accounts into the argument 

    # If the account id exists then it will update the account table with the length of time
    IF accountID IS NOT NULL THEN
        UPDATE account
        SET paying_Fee = paying_Fee + p_length_of_time
        WHERE account_ID = accountID;

        SELECT 'Time added' AS Result;
        #If account name exists then it will print the above string
    ELSE
        SELECT 'Account does not exist. Insert an existing account name.' AS Result;
        #If account name does not exist it will print above string
    END IF;
END // # Ending the procedure

DELIMITER ; 

# We will be calling the procedure name and selecting the account name along with adding the length time.
CALL spAddTime('Dreamybee2701', 10);
