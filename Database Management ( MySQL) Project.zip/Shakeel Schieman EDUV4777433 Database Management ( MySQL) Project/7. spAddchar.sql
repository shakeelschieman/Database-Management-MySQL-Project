/***************************************************************
* Author:   Shakeel Schieman
* Date:     16 January 2024
* Filename: spAddchar.sql
* Description: This sql file will be showing the forth procedure created.
****************************************************************/

DELIMITER //
DROP PROCEDURE IF EXISTS spAddchar;
CREATE PROCEDURE spAddChar(
    IN p_account_ID INT,
    IN p_character_Name VARCHAR(30),
    IN p_character_Team VARCHAR(30),
    IN p_character_Skill_Level INT
    # Creating the character and account arguments
)
BEGIN
    DECLARE accountExists INT;
    DECLARE newCharacterID INT;
    # Creating 2 different arguments/ variables

    # Check to see if the account exists
    SELECT COUNT(*) INTO accountExists
    FROM account
    WHERE account_ID = p_account_ID;

    # If the account exists we will add the character to the account
    IF accountExists > 0 THEN
        INSERT INTO characters (character_Name, character_Team, character_Skill_Level)
        VALUES (p_character_Name, p_character_Team, p_character_Skill_Level);

        # Trying to retrieve the ID of the added character by the user
        SELECT LAST_INSERT_ID() INTO newCharacterID;

        # Linking the character to the account above
        INSERT INTO accountCharacter (account_ID, character_ID)
        VALUES (p_account_ID, newCharacterID);

        SELECT 'Character added to the account ' AS Result;
    ELSE
        SELECT 'Account does not exist' AS Result;
    END IF;
END //

DELIMITER ;

# Calling the procedure
# I have created TWO call functions to display one result with account not existing and the other result with the account existing

CALL spAddChar(1, 'Elsa', 'Team F', 17); #Existing account

CALL spAddchar (1281, 'Sonic', 'Team A', 15); # Non existing

SELECT * FROM characters; #  Displaying that the character has been added to the account
