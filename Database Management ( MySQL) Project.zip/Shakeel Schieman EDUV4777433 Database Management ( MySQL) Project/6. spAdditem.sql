/***************************************************************
* Author:   Shakeel Schieman
* Date:     16 January 2024
* Filename: spAdditem.sql
* Description: This sql file will be showing the third procedure created.
****************************************************************/

DELIMITER //
DROP PROCEDURE IF EXISTS spAdditem;
CREATE PROCEDURE spAddItem(
    IN p_character_ID INT,
    IN p_item_Name VARCHAR(20),
    IN p_item_Type VARCHAR(20)
)
BEGIN
    DECLARE inventorySpace INT;

    # Making sure its in a number format
    SELECT COUNT(*) INTO inventorySpace
    FROM inventory
    WHERE inventory_ID = p_character_ID
        AND (
            inventory_slot_1 IS NULL OR
            inventory_slot_2 IS NULL OR
            inventory_slot_3 IS NULL OR
            inventory_slot_4 IS NULL OR
            inventory_slot_5 IS NULL OR
            inventory_slot_6 IS NULL OR
            inventory_slot_7 IS NULL OR
            inventory_slot_8 IS NULL
        );

    # Making sure that f there is space it will add the item to the character's inventory
    IF inventorySpace> 0 THEN
        INSERT INTO item (item_Name, item_Type, character_ID)
        VALUES (p_item_Name, p_item_Type, p_character_ID);

        SELECT 'Item is added' AS Result;
        # If there is space in the inventory slots then it will print the above string
    ELSE
        SELECT 'Inventory is full.' AS Result;
        # If there is no space available then it will print the string above.
    END IF;
END //

DELIMITER ;

# CAlling the procedure.
CALL spadditem(1, 'Shield', 'Armor')
