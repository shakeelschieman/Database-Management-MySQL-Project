/***************************************************************
* Author:   Shakeel Schieman
* Date:     16 January 2024
* Filename: Triggers 1.1.sql
* Description: This sql file will show how the first trigger works
****************************************************************/
USE multiplayeronlinegame;

DELIMITER //

CREATE TRIGGER after_insert_characters
AFTER INSERT
ON characters FOR EACH ROW
BEGIN
    UPDATE characters
    SET character_Team = UPPER(NEW.character_Team)
    # Making the character_team variable to display in all UPPER case
    WHERE character_ID = NEW.character_ID;
END //

DELIMITER ;

-- Inserting a new character
INSERT INTO characters (character_Name, character_Team, character_Skill_Level)
VALUES ('Grinch', 'Team Z', 18);

SELECT * FROM characters; # Displaying newly added data from table
